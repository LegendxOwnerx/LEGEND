# Edge Control UI Design Plan

## Visual direction

The app uses a portrait-first, one-handed Android layout inspired by the supplied references. The visual language is a near-black navy background, thin cyan outlines, electric cyan primary actions, muted lime status accents, and a single yellow accent around the access field and logo halo. Surfaces are layered with subtle gradients and soft shadows rather than flat white panels.

## Screen list

| Screen | Primary content and functionality |
|---|---|
| Access Console | Brand banner, online status, centered Edge Control logo, product title and subtitle, license-key field with visibility toggle and clipboard paste action, connect CTA, encrypted-vault note, and get-access action. Existing license validation and clipboard behavior remain intact. |
| Protected Session | App header with logo and online state, protected-session card with validity timestamp, progress rail, four countdown cells, BGMI runtime card with app icon/version/status, privacy-mode checkbox, start/uninstall actions, and Edge Server Status card. Existing countdown, OBB preparation, and game launch behavior remain intact. |

## Layout and positioning

The Access Console keeps the centered branding block in the upper half, followed by one large outlined card with generous internal padding. The Protected Session screen uses a compact top header, then a large session card, then the BGMI Runtime section and one lower server-status card. Horizontal margins stay near 24dp on phone screens, cards use 22–26dp corner radii, and controls maintain at least 48dp touch height.

## Key user flows

1. The user opens the app and sees the Access Console.
2. The user enters a license key, optionally toggles visibility, or pastes a key from the clipboard.
3. The user taps Connect to Edge Server; the existing validation flow either reports an error or opens the protected session.
4. On the protected session screen, the countdown updates every second against the existing native expiry date.
5. The user taps Start BGMI; the existing virtual install, OBB copy, and launch flow runs with progress feedback.
6. The user can use the existing secondary actions to prepare game data, clear login data, or open the access link.

## Brand colors

| Token | Color | Use |
|---|---|---|
| Background | #070D1A | Full-screen base |
| Deep surface | #0A1421 | Cards and lower panels |
| Cyan | #39C8F2 | Primary CTA, active labels, logo glow |
| Yellow | #F1D632 | Key field outline, logo halo, primary accent |
| Mint | #65E4BC | Online, secure, ready states |
| Primary text | #F5F7FB | Headings and high-priority values |
| Secondary text | #A7B4C8 | Supporting copy |
| Muted text | #657287 | Metadata and captions |
| Border | #24556B | Outlined cards and separators |

## Implementation notes

The supplied native Android project remains the source of truth. XML layouts and drawable resources will be updated instead of introducing a new web stack. Existing view IDs required by `LogAct` and `MAct` will be preserved so the app’s license, clipboard, countdown, OBB, and launch behavior continues to compile and function.
