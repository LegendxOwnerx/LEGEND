# Edge Control Android Source

This is the supplied native Android project updated to mirror the provided Edge Control access and protected-session screenshots. The original license validation, clipboard paste, countdown timer, OBB preparation, and BGMI launch flow remain wired to the existing activity IDs.

## Build

Open the project in Android Studio, allow Gradle to sync, and use **Build > Generate App Bundles or APKs > Generate APKs**. From a terminal, run `./gradlew assembleDebug` for a debug APK or `./gradlew assembleRelease` for the signed release variant configured in the supplied project.

The APK output paths are `app/build/outputs/apk/debug/app-debug.apk` and `app/build/outputs/apk/release/app-release.apk`.

## UI changes

The access screen now follows the first reference: OneCore Edge header, centered logo/title block, outlined Access Console card, yellow license field, cyan connect button, vault note, and server footer. The protected-session screen now follows the second reference: protected-session card, four timer cells, BGMI Runtime card, privacy-mode row, yellow START BGMI button, and Edge Server Status panel.
