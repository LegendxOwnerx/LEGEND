# Project TODO

- [x] Recreate the supplied login/access screen with matching dark neon styling and positions
- [x] Recreate the supplied protected-session dashboard with matching cards, timer cells, runtime card, and server status card
- [x] Preserve existing license validation, clipboard paste, countdown, OBB preparation, and BGMI launch behavior
- [x] Add responsive portrait layout handling for common Android phone sizes
- [x] Build and smoke-test the debug APK
- [x] Package the updated Android source as a ZIP

- [x] Compact all access-console and protected-session cards to match the smaller reference proportions
- [x] Rebuild and repackage the compact APK and source archive

- [x] Refine the main activity to more closely match the second supplied reference image
- [x] Refine the login activity to more closely match the first supplied reference image
- [x] Rebuild and repackage the refined APK and source archive

- [x] Align the full app theme with the supplied reference images across both screens
- [x] Rebuild and repackage the themed APK and source archive

- [x] Reduce Main Activity card dimensions by approximately 30% without changing the login screen
- [x] Leave approximately 30% empty space below the Main Activity server-status card
- [x] Rebuild and repackage the Main Activity update

- [x] Remove Main Activity scrolling so the compact dashboard stays fixed on one screen
- [x] Use a flexible spacer to leave approximately 40% empty space below the server-status card
- [x] Rebuild and repackage the non-scrolling Main Activity update

- [x] Rename Main Activity and Login Activity branding to XloX LOADER
- [x] Update the Android app label to XloX LOADER
- [x] Rebuild and repackage the renamed APK and source archive
