#include <jni.h>
#include <string>
#include <android/log.h>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/md5.h>
#include <openssl/aes.h>
#include <json.hpp>
#include <obfuscate.h>
#include "oxorany.h"
#include <openssl/sha.h> 
#define LOG_TAG "SignatureCheck"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using json = nlohmann::ordered_json;

time_t rng = 0;
std::string Enc;
static char ZENINOP[64];
static std::string exdate = oxorany ("NULL");

std::string g_Token, g_Auth;
bool bValid = false;


extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_MAct_exdate(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(exdate.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_MAct_ZENINOP(JNIEnv *env, jobject activityObject) {
    return env->NewStringUTF(ZENINOP);
}
extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_LogAct_GetKey(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(oxorany("https://t.me/LEGEND_CHETS")); // Link
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Version(JNIEnv *env, jclass clazz) {
    // No update endpoint is configured. Keep update checks offline-safe.
    const char *versionUrl = "https://github.com/LegendxOwnerx/LEGEND/releases/download/LegendxLoader/version.txt";
    return env->NewStringUTF(versionUrl);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Link(JNIEnv *env, jclass clazz) {
    const char *downloadUrl = (oxorany("https://github.com/LegendxOwnerx/LEGEND/releases/download/LegendxLoader/LEGENDX.zip"));
    return env->NewStringUTF(downloadUrl);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_BoxApplication_getSdkKey(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(oxorany("BUNNY-0396F49E-278"));//sdk key 
}


// Expected SHA-256 signature
static const char *EXPECTED_SIGNATURE ="77f05d53ce8bf1855caef38ce87f13a8bb2b1b2cdd2d48da9d3ba897eac4549e";

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_bgmi_LogAct_nativeVerifySignature(JNIEnv *env, jobject thiz, jobject context) {
    jclass contextClass = env->GetObjectClass(context);

    // Get PackageManager
    jmethodID midGetPM = env->GetMethodID(contextClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    jobject pm = env->CallObjectMethod(context, midGetPM);

    // Get package name
    jmethodID midGetPkg = env->GetMethodID(contextClass, "getPackageName", "()Ljava/lang/String;");
    jstring pkgName = (jstring) env->CallObjectMethod(context, midGetPkg);

    // Get package info with signatures (flag = 64)
    jclass pmClass = env->GetObjectClass(pm);
    jmethodID midGetInfo = env->GetMethodID(pmClass, "getPackageInfo",
                                            "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    jobject pkgInfo = env->CallObjectMethod(pm, midGetInfo, pkgName, 64);

    // Get signatures[]
    jclass pkgInfoClass = env->GetObjectClass(pkgInfo);
    jfieldID fidSignatures = env->GetFieldID(pkgInfoClass, "signatures", "[Landroid/content/pm/Signature;");
    jobjectArray sigArray = (jobjectArray) env->GetObjectField(pkgInfo, fidSignatures);

    if (sigArray == nullptr) return JNI_FALSE;

    jsize sigCount = env->GetArrayLength(sigArray);
    for (jsize i = 0; i < sigCount; i++) {
        jobject sig = env->GetObjectArrayElement(sigArray, i);

        jclass sigClass = env->GetObjectClass(sig);
        jmethodID midToBytes = env->GetMethodID(sigClass, "toByteArray", "()[B");
        jbyteArray sigBytes = (jbyteArray) env->CallObjectMethod(sig, midToBytes);

        jsize len = env->GetArrayLength(sigBytes);
        jbyte *buf = env->GetByteArrayElements(sigBytes, nullptr);

        // Hash with SHA-256
        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256((unsigned char *) buf, len, hash);

        env->ReleaseByteArrayElements(sigBytes, buf, 0);

        // Convert hash to hex string
        char hexHash[SHA256_DIGEST_LENGTH * 2 + 1];
        for (int j = 0; j < SHA256_DIGEST_LENGTH; j++) {
            sprintf(&hexHash[j * 2], "%02x", hash[j]);
        }
        hexHash[SHA256_DIGEST_LENGTH * 2] = '\0';

        if (strcasecmp(hexHash, EXPECTED_SIGNATURE) == 0) {
            return JNI_TRUE;
        } else {
            LOGE("Invalid signature: %s", hexHash);
        }
    }
    return JNI_FALSE;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,"getContentResolver","()Landroid/content/ContentResolver;");
    jclass settingSecureClass = env->FindClass("android/provider/Settings$Secure");
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass,"getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,env->NewStringUTF("android_id"));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "MODEL","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "BRAND","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getPackageNameId = env->GetMethodID(contextClass, "getPackageName","()Ljava/lang/String;");

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass("java/util/UUID");

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,"nameUUIDFromBytes","([B)Ljava/util/UUID;");
    jmethodID toStringMethod = env->GetMethodID(uuidClass, "toString","()Ljava/lang/String;");

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}
std::string CalcMD5(std::string s) {
    std::string result;

    unsigned char hash[MD5_DIGEST_LENGTH];
    char tmp[4];

    MD5_CTX md5;
    MD5_Init(&md5);
    MD5_Update(&md5, s.c_str(), s.length());
    MD5_Final(hash, &md5);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}

std::string CalcSHA256(std::string s) {
    std::string result;

    unsigned char hash[SHA256_DIGEST_LENGTH];
    char tmp[4];

    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, s.c_str(), s.length());
    SHA256_Final(hash, &sha256);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_LogAct_Check(JNIEnv *env, jclass clazz, jobject mContext, jstring mUserKey) {
    // Reset authentication state on every attempt.
    bValid = false;
    g_Token.clear();
    g_Auth.clear();
    Enc.clear();
    exdate = "NULL";
    rng = 0;

    if (mUserKey == nullptr) {
        return env->NewStringUTF("Invalid key");
    }

    const char *user_key = env->GetStringUTFChars(mUserKey, 0);
    if (user_key == nullptr || *user_key == '\0') {
        if (user_key != nullptr) env->ReleaseStringUTFChars(mUserKey, user_key);
        return env->NewStringUTF("Invalid key");
    }

    std::string hwid = user_key;
    hwid += GetAndroidID(env, mContext);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());

    std::string errMsg;
    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

    CURL *curl = curl_easy_init();
    if (!curl) {
        env->ReleaseStringUTFChars(mUserKey, user_key);
        free(chunk.memory);
        return env->NewStringUTF("Could not initialize network");
    }

    // The panel expects application/x-www-form-urlencoded data. Escape both
    // values so keys containing &, +, =, etc. cannot corrupt the request.
    char *escapedKey = curl_easy_escape(curl, user_key, 0);
    char *escapedSerial = curl_easy_escape(curl, UUID.c_str(), 0);

    if (escapedKey == nullptr || escapedSerial == nullptr) {
        if (escapedKey) curl_free(escapedKey);
        if (escapedSerial) curl_free(escapedSerial);
        curl_easy_cleanup(curl);
        env->ReleaseStringUTFChars(mUserKey, user_key);
        free(chunk.memory);
        return env->NewStringUTF("Could not encode login request");
    }

    std::string postData = "game=PUBG&user_key=";
    postData += escapedKey;
    postData += "&serial=";
    postData += escapedSerial;

    curl_free(escapedKey);
    curl_free(escapedSerial);

    curl_easy_setopt(curl, CURLOPT_URL, "https://naman-panel.cu.ma/connect");
    curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "POST");
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, "https");
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 15L);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 30L);

    struct curl_slist *headers = nullptr;
    headers = curl_slist_append(headers, "Accept: application/json");
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded; charset=UTF-8");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_POSTFIELDSIZE, (long) postData.size());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYSTATUS, 0L);
    curl_easy_setopt(curl, CURLOPT_USERAGENT, "SrcHub9/1.0");

    CURLcode res = curl_easy_perform(curl);

    long httpCode = 0;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);

    if (res == CURLE_OK) {
        if (chunk.memory == nullptr || chunk.size == 0) {
            errMsg = "Empty panel response (HTTP " + std::to_string(httpCode) + ")";
        } else {
            try {
                json result = json::parse(chunk.memory, nullptr, true, true);

                // Accept the normal response and a few harmless naming variants
                // used by older panel versions (enc/encryption, expiry, etc.).
                auto readText = [](const json &obj, std::initializer_list<const char*> names) -> std::string {
                    if (!obj.is_object()) return "";
                    for (const char *name : names) {
                        if (obj.contains(name)) {
                            const auto &v = obj[name];
                            if (v.is_string()) return v.get<std::string>();
                            if (!v.is_null()) return v.dump();
                        }
                    }
                    return "";
                };

                auto readStatus = [](const json &obj) -> bool {
                    if (!obj.is_object() || !obj.contains("status")) return false;
                    const auto &v = obj["status"];
                    if (v.is_boolean()) return v.get<bool>();
                    if (v.is_number_integer()) return v.get<long long>() != 0;
                    if (v.is_string()) {
                        std::string s = v.get<std::string>();
                        return s == "true" || s == "1" || s == "OK" || s == "ok" || s == "success";
                    }
                    return false;
                };

                const json *dataObj = &result;
                if (result.contains("data") && result["data"].is_object()) {
                    dataObj = &result["data"];
                }

                bool status = readStatus(result);
                if (!status && dataObj != &result) {
                    status = readStatus(*dataObj);
                }

                if (!status) {
                    std::string reason = readText(result, {"reason", "message", "msg", "error"});
                    errMsg = reason.empty() ? "Panel rejected the login key (HTTP " + std::to_string(httpCode) + ")" : reason;
                } else {
                    std::string token = readText(*dataObj, {"token", "Token", "TOKEN"});
                    Enc = readText(*dataObj, {"Enc", "enc", "encryption", "Encryption", "key"});
                    exdate = readText(*dataObj, {"EXP", "exp", "expiry", "expiration", "expires"});

                    if (dataObj->contains("rng")) {
                        const auto &rv = (*dataObj)["rng"];
                        if (rv.is_number_integer()) {
                            rng = rv.get<time_t>();
                        } else if (rv.is_string()) {
                            try { rng = static_cast<time_t>(std::stoll(rv.get<std::string>())); }
                            catch (...) { rng = 0; }
                        }
                    }

                    if (token.empty() || Enc.empty()) {
                        // Do not hide the real server response behind the old
                        // generic message. This makes panel-side schema changes
                        // immediately diagnosable from the app.
                        std::string body(chunk.memory, chunk.size);
                        if (body.size() > 300) body.resize(300);
                        errMsg = "Invalid panel response (HTTP " + std::to_string(httpCode) + "): " + body;
                    } else if (rng <= 0 || rng + 30 > time(0)) {
                        std::string auth = "PUBG-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
                        auth += oxorany("LEGENDXMODLICENCE");

                        std::string outputAuth = CalcMD5(auth);
                        g_Token = token;
                        g_Auth = outputAuth;
                        bValid = (g_Token == g_Auth);

                        if (bValid) {
                            snprintf(ZENINOP, sizeof(ZENINOP), "%s", Enc.c_str());
                            printf(oxorany("Login Success\n"));
                        } else {
                            errMsg = "Panel token mismatch";
                        }
                    } else {
                        errMsg = "Login response expired";
                    }
                }
            } catch (const json::exception &e) {
                std::string body(chunk.memory ? chunk.memory : "", chunk.size);
                if (body.size() > 300) body.resize(300);
                errMsg = "Invalid JSON from panel (HTTP " + std::to_string(httpCode) + "): " + body;
            }
        }
    } else {
        errMsg = std::string("Network error: ") + curl_easy_strerror(res);
        if (httpCode > 0) errMsg += " (HTTP " + std::to_string(httpCode) + ")";
    }

    if (headers) curl_slist_free_all(headers);
    curl_easy_cleanup(curl);
    env->ReleaseStringUTFChars(mUserKey, user_key);
    free(chunk.memory);

    return bValid ? env->NewStringUTF("OK") : env->NewStringUTF(errMsg.empty() ? "Login failed" : errMsg.c_str());
}
