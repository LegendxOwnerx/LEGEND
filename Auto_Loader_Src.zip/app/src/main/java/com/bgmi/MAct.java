package com.bgmi;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.graphics.Color;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;
import android.util.Base64;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.bgmi.utils.AppManager;
import com.bgmi.utils.Downtwo;
import org.lsposed.lsparanoid.Obfuscate;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import top.Vspace.blackbox.BlackBoxCore;
import top.Vspace.blackbox.entity.pm.InstallResult;
import top.Vspace.blackbox.core.env.BEnvironment;
@Obfuscate
public class MAct extends AppCompatActivity {
    static {
        try {
            System.loadLibrary("PRIVATE_SRC_FILES");
        } catch (UnsatisfiedLinkError ignored) {}
    }
    private static final String PKG_BGMI = "com.tencent.ig";
 //   private static final String PKG_TWITTER = "com.twitter.android";
    private static final int USER_ID = 0;
    // Progress UI elements removed
    private boolean isObbCopied = false;
    private AppManager appManager;
    // Native methods
    public static native String exdate();
    
    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        appManager = new AppManager(this);
        doCountTimerAccout();
        // Progress elements removed as they don't exist in current layout
        // progressBar = findViewById(R.id.progressBar);
        // progressText = findViewById(R.id.progressText);
        // BGMI INSTALL/UNINSTALL
        Button installGame = findViewById(R.id.installGame);
        Button uninstallGame = findViewById(R.id.uninstallGame);
        TextView statusText = findViewById(R.id.statusText);
        if (statusText != null) {
            String full = "Status : Live";
            SpannableString span = new SpannableString(full);
            int idx = full.indexOf("Live");
            if (idx >= 0) {
                span.setSpan(new ForegroundColorSpan(ContextCompat.getColor(this, R.color.status_live)), idx, idx + 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }
            statusText.setText(span);
        }

        Button startGame = findViewById(R.id.startGame);
        Button stopGame = findViewById(R.id.stopGame);
        Button hideExpired = findViewById(R.id.hideExpired);
        Button hideEsp = findViewById(R.id.hideEsp);
        android.view.View expiryCard = findViewById(R.id.expiryCard);

        startGame.setOnClickListener(v -> launchGame());
        stopGame.setOnClickListener(v -> Toast.makeText(this, "Stop request sent", Toast.LENGTH_SHORT).show());
        hideExpired.setOnClickListener(v -> {
            boolean hidden = expiryCard.getVisibility() == android.view.View.VISIBLE;
            expiryCard.setVisibility(hidden ? android.view.View.GONE : android.view.View.VISIBLE);
            hideExpired.setText(hidden ? "SHOW EXPIRED TIME" : "HIDE EXPIRED TIME");
        });
        hideEsp.setOnClickListener(v -> {
            boolean showing = hideEsp.getText().toString().equals("HIDE ESP");
            hideEsp.setText(showing ? "SHOW ESP" : "HIDE ESP");
            Toast.makeText(this, showing ? "ESP hidden" : "ESP visible", Toast.LENGTH_SHORT).show();
        });
        
        installGame.setOnClickListener(v -> {
            try {
                if (BlackBoxCore.get() != null) {
                    boolean isInstalled = BlackBoxCore.get().isInstalled(PKG_BGMI, USER_ID);
                    if (!isInstalled) {
                        InstallResult result = BlackBoxCore.get().installPackageAsUser(PKG_BGMI, USER_ID);
                        if (result.success) {
                            Toast.makeText(this, "BGMI installed. Please wait...", Toast.LENGTH_SHORT).show();
                            updateButtonUI(); 
                        } else {
                            Toast.makeText(this, "Install failed: " + result.msg, Toast.LENGTH_SHORT).show();
                        }
                    } else if (!isObbCopied) {
                        copyObbFiles();
                    } else {
                        launchGame();
                    }
                } else {
                     Toast.makeText(this, "Core service not ready", Toast.LENGTH_SHORT).show();
                }
            } catch (Throwable e) {
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                e.printStackTrace();
            }
        });
        
        uninstallGame.setOnClickListener(v -> {
            try {
                if (BlackBoxCore.get() != null && BlackBoxCore.get().isInstalled(PKG_BGMI, USER_ID)) {
                    // Uninstall logic would go here
                    Toast.makeText(this, "Uninstall feature not implemented", Toast.LENGTH_SHORT).show();
                    // If we had uninstall logic, we'd call updateButtonUI() after success
                } else {
                    Toast.makeText(this, "Game not installed", Toast.LENGTH_SHORT).show();
                }
            } catch (Throwable e) {
                Toast.makeText(this, "Error checking status", Toast.LENGTH_SHORT).show();
            }
        });
        // Initialize UI state
        updateButtonUI();
        // TWITTER START
       // Button twitterBtn = findViewById(R.id.startTwitter);
      //  twitterBtn.setOnClickListener(v -> handleAppInstall(PKG_TWITTER, "Twitter"));
    }
    @Override
    protected void onResume() {
        super.onResume();
        updateButtonUI();
    }
    private void updateButtonUI() {
        try {
            Button installGame = findViewById(R.id.installGame);
            Button uninstallGame = findViewById(R.id.uninstallGame);
            if (installGame == null || uninstallGame == null) return;
            boolean isInstalled = false;
            try {
                if (BlackBoxCore.get() != null) {
                    isInstalled = BlackBoxCore.get().isInstalled(PKG_BGMI, USER_ID);
                }
            } catch (Throwable e) {
                // If ZCoreCore throws, assume not installed or handle gracefully
                e.printStackTrace();
            }
            if (isInstalled) {
                // STATE 2: Game Installed
                installGame.setText("PLAY GAME");
                installGame.setTextColor(ContextCompat.getColor(this, R.color.white));
                // Safe tinting
                androidx.core.view.ViewCompat.setBackgroundTintList(installGame, 
                    android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.status_live)));
                
                uninstallGame.setText("UNINSTALL GAME");
                uninstallGame.setTextColor(ContextCompat.getColor(this, R.color.white));
                uninstallGame.setEnabled(true);
                androidx.core.view.ViewCompat.setBackgroundTintList(uninstallGame, 
                    android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.package_red)));
            } else {
                // STATE 1: Game Not Installed
                installGame.setText("INSTALL GAME");
                installGame.setTextColor(ContextCompat.getColor(this, R.color.white));
                androidx.core.view.ViewCompat.setBackgroundTintList(installGame, 
                    android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.button_cyan)));
                uninstallGame.setText("UNINSTALL GAME");
                uninstallGame.setTextColor(ContextCompat.getColor(this, R.color.white)); 
                uninstallGame.setEnabled(false);
                androidx.core.view.ViewCompat.setBackgroundTintList(uninstallGame, 
                    android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, R.color.button_gray)));
            }
        } catch (Throwable e) {
            e.printStackTrace(); // Prevent crash in UI update
        }
    }
    /** Expiry countdown */
    private void doCountTimerAccout() {
        android.os.Handler handler = new android.os.Handler();
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                try {
                    handler.postDelayed(this, 1000);
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date expiryDate = dateFormat.parse(exdate());
                    long now = System.currentTimeMillis();
                    long distance = expiryDate.getTime() - now;
                    long d = distance / (24 * 60 * 60 * 1000);
                    long h = (distance / (60 * 60 * 1000)) % 24;
                    long m = (distance / (60 * 1000)) % 60;
                    long s = (distance / 1000) % 60;
                    if (distance < 0) {
                        Toast.makeText(MAct.this, "License expired!", Toast.LENGTH_SHORT).show();
                        ((TextView) findViewById(R.id.tvD)).setText("000");
                        ((TextView) findViewById(R.id.tvH)).setText("00");
                        ((TextView) findViewById(R.id.tvM)).setText("00");
                        ((TextView) findViewById(R.id.tvS)).setText("00");
                    } else {
                        ((TextView) findViewById(R.id.tvD)).setText(String.format("%03d", d));
                        ((TextView) findViewById(R.id.tvH)).setText(String.format("%02d", h));
                        ((TextView) findViewById(R.id.tvM)).setText(String.format("%02d", m));
                        ((TextView) findViewById(R.id.tvS)).setText(String.format("%02d", s));
                    }
                } catch (Throwable ignored) {
                    // Catch Error (UnsatisfiedLinkError) and Exception
                }
            }
        };
        handler.postDelayed(runnable, 0);
    }
    /** Copy OBB with progress */
    private void copyObbFiles() {
        // Progress UI elements removed - show toast instead
        Toast.makeText(this, "Copying OBB...", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                PackageInfo info = getPackageManager().getPackageInfo(PKG_BGMI, 0);
                String gameObb = "main." + info.versionCode + "." + info.packageName + ".obb";
                File obbSource = new File(Environment.getExternalStorageDirectory(),
                        "Android/obb/" + PKG_BGMI + "/" + gameObb);
                File obbDestDir = BEnvironment.getExternalObbDir(PKG_BGMI);
                if (!obbDestDir.exists()) obbDestDir.mkdirs();
                File obbDestFile = new File(obbDestDir, gameObb);
                if (obbDestFile.exists()) {
                    runOnUiThread(() -> {
                        isObbCopied = true;
                        Toast.makeText(MAct.this, "OBB already exists", Toast.LENGTH_SHORT).show();
                        launchGame();
                    });
                    return;
                }
                java.io.FileInputStream fis = new java.io.FileInputStream(obbSource);
                java.io.FileOutputStream fos = new java.io.FileOutputStream(obbDestFile);
                long total = obbSource.length();
                long copied = 0;
                byte[] buf = new byte[8192];
                int len;
                while ((len = fis.read(buf)) != -1) {
                    fos.write(buf, 0, len);
                    copied += len;
                    int prog = (int) ((copied * 100) / total);
                    runOnUiThread(() -> {
                        // Progress UI removed - show toast for major milestones
                        if (prog % 25 == 0) {
                            Toast.makeText(MAct.this, "Copying OBB: " + prog + "%", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
                fis.close();
                fos.close();
                runOnUiThread(() -> {
                    isObbCopied = true;
                    Toast.makeText(MAct.this, "Ready to launch", Toast.LENGTH_SHORT).show();
                    launchGame();
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "OBB copy failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }
    /** Launch BGMI */
    private void launchGame() {
        try {
            BlackBoxCore.get().launchApk(PKG_BGMI, USER_ID);
            Toast.makeText(this, "Launching BGMI...", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Launch failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
    /** Install or launch app */
    private void handleAppInstall(String pkg, String name) {
        if (BlackBoxCore.get().isInstalled(pkg, USER_ID)) {
            BlackBoxCore.get().launchApk(pkg, USER_ID);
        } else {
            InstallResult result = BlackBoxCore.get().installPackageAsUser(pkg, USER_ID);
            if (result.success) {
                Toast.makeText(this, name + " installed!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Failed: " + result.msg, Toast.LENGTH_SHORT).show();
            }
        }
    }
}
