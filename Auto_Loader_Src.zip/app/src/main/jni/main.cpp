#include <jni.h>
#include <string>
#include <android/log.h>
#include <curl/curl.h>
#include <openssl/evp.h>
#include <openssl/pem.h>
#include <openssl/rsa.h>
#include <openssl/err.h>
#include <openssl/md5.h>
#include <openssl/aes.h>
#include <json.hpp>
#include <obfuscate.h>
#include "oxorany.h"
#include <openssl/sha.h> 
#define LOG_TAG "SignatureCheck"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

using json = nlohmann::ordered_json;

time_t rng = 0;
std::string Enc;
static char ZENINOP[64];
static std::string exdate = oxorany ("NULL");

std::string g_Token, g_Auth;
bool bValid = false;


extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_MAct_exdate(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(exdate.c_str());
}
extern "C" JNIEXPORT jstring JNICALL
Java_com_bgmi_MAct_ZENINOP(JNIEnv *env, jobject activityObject) {
    return env->NewStringUTF(ZENINOP);
}
extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_LogAct_GetKey(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(oxorany("https://t.me/HackingClub9")); // Link Channel
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Version(JNIEnv *env, jclass clazz) {
    // No update endpoint is configured. Keep update checks offline-safe.
    const char *versionUrl = "https://github.com/LegendxOwnerx/LEGEND/releases/download/LegendxLoader/version.txt";
    return env->NewStringUTF(versionUrl);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_utils_Downtwo_Link(JNIEnv *env, jclass clazz) {
    const char *downloadUrl = (oxorany("https://github.com/LegendxOwnerx/LEGEND/releases/download/LegendxLoader/LEGENDX.ZIP"));
    return env->NewStringUTF(downloadUrl);
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_bgmi_BoxApplication_getSdkKey(JNIEnv *env, jclass clazz) {
    return env->NewStringUTF(oxorany("@HackingClub9"));//sdk key 
}


// Expected SHA-256 signature
static const char *EXPECTED_SIGNATURE ="77f05d53ce8bf1855caef38ce87f13a8bb2b1b2cdd2d48da9d3ba897eac4549e";

extern "C"
JNIEXPORT jboolean JNICALL
Java_com_bgmi_LogAct_nativeVerifySignature(JNIEnv *env, jobject thiz, jobject context) {
    jclass contextClass = env->GetObjectClass(context);

    // Get PackageManager
    jmethodID midGetPM = env->GetMethodID(contextClass, "getPackageManager", "()Landroid/content/pm/PackageManager;");
    jobject pm = env->CallObjectMethod(context, midGetPM);

    // Get package name
    jmethodID midGetPkg = env->GetMethodID(contextClass, "getPackageName", "()Ljava/lang/String;");
    jstring pkgName = (jstring) env->CallObjectMethod(context, midGetPkg);

    // Get package info with signatures (flag = 64)
    jclass pmClass = env->GetObjectClass(pm);
    jmethodID midGetInfo = env->GetMethodID(pmClass, "getPackageInfo",
                                            "(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;");
    jobject pkgInfo = env->CallObjectMethod(pm, midGetInfo, pkgName, 64);

    // Get signatures[]
    jclass pkgInfoClass = env->GetObjectClass(pkgInfo);
    jfieldID fidSignatures = env->GetFieldID(pkgInfoClass, "signatures", "[Landroid/content/pm/Signature;");
    jobjectArray sigArray = (jobjectArray) env->GetObjectField(pkgInfo, fidSignatures);

    if (sigArray == nullptr) return JNI_FALSE;

    jsize sigCount = env->GetArrayLength(sigArray);
    for (jsize i = 0; i < sigCount; i++) {
        jobject sig = env->GetObjectArrayElement(sigArray, i);

        jclass sigClass = env->GetObjectClass(sig);
        jmethodID midToBytes = env->GetMethodID(sigClass, "toByteArray", "()[B");
        jbyteArray sigBytes = (jbyteArray) env->CallObjectMethod(sig, midToBytes);

        jsize len = env->GetArrayLength(sigBytes);
        jbyte *buf = env->GetByteArrayElements(sigBytes, nullptr);

        // Hash with SHA-256
        unsigned char hash[SHA256_DIGEST_LENGTH];
        SHA256((unsigned char *) buf, len, hash);

        env->ReleaseByteArrayElements(sigBytes, buf, 0);

        // Convert hash to hex string
        char hexHash[SHA256_DIGEST_LENGTH * 2 + 1];
        for (int j = 0; j < SHA256_DIGEST_LENGTH; j++) {
            sprintf(&hexHash[j * 2], "%02x", hash[j]);
        }
        hexHash[SHA256_DIGEST_LENGTH * 2] = '\0';

        if (strcasecmp(hexHash, EXPECTED_SIGNATURE) == 0) {
            return JNI_TRUE;
        } else {
            LOGE("Invalid signature: %s", hexHash);
        }
    }
    return JNI_FALSE;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,"getContentResolver","()Landroid/content/ContentResolver;");
    jclass settingSecureClass = env->FindClass("android/provider/Settings$Secure");
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass,"getString", "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;");

    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,env->NewStringUTF("android_id"));
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "MODEL","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass("android/os/Build");
    jfieldID modelId = env->GetStaticFieldID(buildClass, "BRAND","Ljava/lang/String;");

    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass("android/content/Context");
    jmethodID getPackageNameId = env->GetMethodID(contextClass, "getPackageName","()Ljava/lang/String;");

    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, 0);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass("java/util/UUID");

    auto len = strlen(uuid);

    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);

    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,"nameUUIDFromBytes","([B)Ljava/util/UUID;");
    jmethodID toStringMethod = env->GetMethodID(uuidClass, "toString","()Ljava/lang/String;");

    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, 0);
}

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    struct MemoryStruct *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == NULL) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}
std::string CalcMD5(std::string s) {
    std::string result;

    unsigned char hash[MD5_DIGEST_LENGTH];
    char tmp[4];

    MD5_CTX md5;
    MD5_Init(&md5);
    MD5_Update(&md5, s.c_str(), s.length());
    MD5_Final(hash, &md5);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}

std::string CalcSHA256(std::string s) {
    std::string result;

    unsigned char hash[SHA256_DIGEST_LENGTH];
    char tmp[4];

    SHA256_CTX sha256;
    SHA256_Init(&sha256);
    SHA256_Update(&sha256, s.c_str(), s.length());
    SHA256_Final(hash, &sha256);
    for (unsigned char i : hash) {
        sprintf(tmp, "%02x", i);
        result += tmp;
    }
    return result;
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_privatesrcwala_LogAct_Check(JNIEnv *env, jclass clazz, jobject mContext, jstring mUserKey) {
    auto user_key = env->GetStringUTFChars(mUserKey, 0);
    std::string hwid = user_key;
    hwid += GetAndroidID(env, mContext);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
    std::string errMsg;
    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

    CURL *curl;
    CURLcode res;
    curl = curl_easy_init();
    if (curl) {
        char lol[1000];
        sprintf(lol,oxorany("https://naman-panel.cu.ma/connect"));
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, oxorany("POST"));
        curl_easy_setopt(curl, CURLOPT_URL, lol);
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, oxorany("https"));
        struct curl_slist *headers = NULL;
        headers = curl_slist_append(headers, oxorany("Accept: application/json"));
        headers = curl_slist_append(headers, oxorany("Content-Type: application/x-www-form-urlencoded"));
        headers = curl_slist_append(headers, oxorany("Charset: UTF-8"));
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        char data[4096];
        sprintf(data, oxorany("game=PUBG&user_key=%s&serial=%s"), user_key, UUID.c_str());
        curl_easy_setopt(curl, CURLOPT_POST, 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYSTATUS, 0);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, oxorany(""));
        res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                const json result = json::parse(chunk.memory);
                if (!result.is_object()) {
                    errMsg = "Invalid server response";
                } else if (result.contains("status") && JsonToBool(result.at("status"))) {
                    if (!result.contains("data") || !result.at("data").is_object()) {
                        errMsg = "Invalid server data";
                    } else {
                        const json& data = result.at("data");
                        if (!data.contains("token") || !data.contains("rng")) {
                            errMsg = "Incomplete server response";
                        } else {
                            const std::string token = JsonToText(data.at("token"));
                            time_t serverTime = 0;
                            if (token.empty() || !JsonToTime(data.at("rng"), serverTime)) {
                                errMsg = "Invalid server response data";
                            } else {
                                if (data.contains("EXP")) exdate = JsonToText(data.at("EXP"));
                                if (serverTime + 30 > time(0)) {
                                    std::string auth = oxorany("PUBG");
                                    auth += "-";
                                    auth += user_key;
                                    auth += "-";
                                    auth += UUID;
                                    auth += "-";
                                    std::string license = oxorany("LEGENDXMODLICENCE");
                                    auth += license;
                                    std::string outputAuth = CalcMD5(auth);
                                    g_Token = token;
                                    g_Auth = outputAuth;
                                    xConnected = g_Token == g_Auth;
                                    xServerConnection = true;
                                    memek = true;
                                    if (xConnected && xServerConnection) {
                                        printf(oxorany("Login Success \\n"));
                                    }
                                } else {
                                    errMsg = "Server response expired";
                                }
                            }
                        }
                    }
                } else {
                    errMsg = result.contains("reason") ? JsonToText(result.at("reason")) : "Login rejected by server";
                    if (errMsg.empty()) errMsg = "Login rejected by server";
                }
            } catch (json::exception &e) {
                errMsg = e.what();
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
    }
    curl_easy_cleanup(curl);
    return xConnected ? env->NewStringUTF(StrEnc("8q", "\x77\x3A", 2).c_str()) : env->NewStringUTF(errMsg.c_str());
}
