# LegendXLoader build-fix notes

## Login crash fix
The login screen called the static native method `com.bgmi.LogAct.Check(...)`, but the JNI implementation was exported as `Java_com_privatesrcwala_LogAct_Check(...)`. That mismatch causes `UnsatisfiedLinkError` when the Login button invokes `Check()` and results in the Activity closing.

The JNI export is now aligned with the Java package/class:

`Java_com_bgmi_LogAct_Check`

The Java login worker also catches Java-side JNI/linkage exceptions and reports them in the existing loading dialog instead of terminating the Activity.

## SDK/library
`app/libs/Tcore-release.aar` is retained as the SDK dependency.

## Build verification limitation
This environment does not contain the Android SDK/NDK toolchains required by this project, and outbound access to `services.gradle.org` is unavailable. Therefore an actual APK build could not be completed here. The source-level fix was inspected after modification.
