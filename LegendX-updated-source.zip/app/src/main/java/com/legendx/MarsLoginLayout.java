package com.legendx;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Keeps the complete login composition on one portrait screen.
 * The design canvas is 390dp x 760dp and is uniformly scaled down on shorter devices.
 */
public class MarsLoginLayout extends FrameLayout {
    private static final float DESIGN_WIDTH_DP = 390f;
    private static final float DESIGN_HEIGHT_DP = 760f;
    private View canvas;
    private float density;

    public MarsLoginLayout(Context context) {
        super(context);
        init(context);
    }

    public MarsLoginLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public MarsLoginLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        density = getResources().getDisplayMetrics().density;
        setClipChildren(true);
        setClipToPadding(true);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        canvas = findViewById(R.id.loginCanvas);
        if (canvas == null) return;

        int canvasWidth = Math.round(DESIGN_WIDTH_DP * density);
        int canvasHeight = Math.round(DESIGN_HEIGHT_DP * density);
        canvas.measure(
                MeasureSpec.makeMeasureSpec(canvasWidth, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(canvasHeight, MeasureSpec.EXACTLY)
        );
    }

    @Override
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (canvas == null) canvas = findViewById(R.id.loginCanvas);
        if (canvas == null) return;

        float availableWidthDp = (right - left) / density;
        float availableHeightDp = (bottom - top) / density;
        float scale = Math.min(availableWidthDp / DESIGN_WIDTH_DP, availableHeightDp / DESIGN_HEIGHT_DP);
        scale = Math.max(0.50f, scale);

        int canvasWidth = Math.round(DESIGN_WIDTH_DP * density);
        int canvasHeight = Math.round(DESIGN_HEIGHT_DP * density);
        int scaledWidth = Math.round(canvasWidth * scale);
        int scaledHeight = Math.round(canvasHeight * scale);
        int canvasLeft = Math.max(0, ((right - left) - scaledWidth) / 2);
        int canvasTop = Math.max(0, ((bottom - top) - scaledHeight) / 2);

        canvas.layout(canvasLeft, canvasTop, canvasLeft + canvasWidth, canvasTop + canvasHeight);
        canvas.setPivotX(0f);
        canvas.setPivotY(0f);
        canvas.setScaleX(scale);
        canvas.setScaleY(scale);
    }
}
