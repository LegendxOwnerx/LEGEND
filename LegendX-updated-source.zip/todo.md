# Project TODO

- [x] Inspect the provided Vision Loader source project
- [x] Add the screenshot-matched MARS Loader password-key login page
- [x] Keep Android Back, Home, and Recent buttons outside the app UI
- [x] Preserve the project’s existing build and signing setup
- [x] Build and validate the updated APK
- [x] Package and deliver the updated source ZIP
- [x] Fit the complete MARS login UI on one portrait screen without vertical scrolling
- [x] Match the reference screenshot’s smaller text sizes and tighter typography
- [x] Add the provided JNI Version() and Link() methods to app/src/main/jni/main.cpp and rebuild
- [x] Add the screenshot-matched inside BGMI selection page after login
- [x] Add the blue Launch button interaction and preserve the existing launch flow
- [x] Recreate the inside-page screenshot with matching geometry, proportions, and visual styling instead of an approximate design
- [ ] Change the inside-page Launch button to bright sky blue and rebuild
